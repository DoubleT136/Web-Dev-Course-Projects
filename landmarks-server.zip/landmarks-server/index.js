// Initialization
var express = require('express');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');
var validator = require('validator');
var app = express();

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use(expressValidator());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
var mongoUri = 'mongodb://heroku_9rrdll2c:5f68ons6hanrs407938hqu9ijb@ds019970.mlab.com:19970/heroku_9rrdll2c';
var MongoClient = require('mongodb').MongoClient, format = require('util').format;
var db = MongoClient.connect(mongoUri, function(error, databaseConnection) {
    db = databaseConnection;
});

app.use(express.static(__dirname + '/public'));

app.post('/sendLocation', function(request, response) {
    request.checkBody('login', 'Whoops, something is wrong with your data!').notEmpty();
    request.checkBody('lat', 'Whoops, something is wrong with your data!').notEmpty();
    request.checkBody('lng', 'Whoops, something is wrong with your data!').notEmpty();
    var errors = request.validationErrors();
    if (errors) {
        response.json({"error":"Whoops, something is wrong with your data!"});
        return;
    }
    var login = request.body.login;
    var lat = parseFloat(request.body.lat);
    var lng = parseFloat(request.body.lng);
    var date = new Date();
    date = date.toISOString();
    if (login == null || lat == null || lng == null) {
        response.json({"error":"Whoops, something is wrong with your data!"});
        return;
    }
    var toInsert = {
        "login": login,
        "lat": lat,
        "lng": lng,
        "created_at": date
    };
    db.collection('checkins', function(error, coll) {
        var id = coll.insert(toInsert, function(error, saved) {
            if (error) {
                response.sendStatus(500);
            } else {
                // Query for landmarks within 1 mile and all logins
                db.collection('landmarks').createIndex({'geometry':"2dsphere"}, function(error, col){
                    if (error) {
                        response.sendStatus(500);
                    } else {
                        db.collection('landmarks').find({geometry:{$near:{$geometry:{type:"Point",coordinates:[lng,lat]},$minDistance: 0 ,$maxDistance: 1609.34}}}).toArray(function(err, cursor1) {
                            if (!err) {
                                db.collection('checkins').find().toArray(function(err, cursor2) {
                                    if (!err) {
                                        response.json({'people': cursor2, 'landmarks': cursor1});
                                    } else {
                                        response.sendStatus(500);
                                    }
                                });
                            } else {
                                response.sendStatus(500);
                            }
                        });
                    }
                });
            }
        });
    });
});

app.get('/checkins.json', function(request, response) {
    var name = request.query.login;
    db.collection('checkins', function(er, collection) {
        collection.find({'login': name}).toArray(function(err, cursor) {
            if (!err) {
                response.json(cursor);
            } else {
                response.sendStatus(500);
            }
        });
    });
});

app.get('/', function(request, response) {
	response.set('Content-Type', 'text/html');
	var indexPage = '';
    db.collection('checkins', function(er, collection) {
        collection.find().toArray(function(err, cursor) {
			if (!err) {
                var prev_date = 0;
				for (var count = 0; count < cursor.length; count++) {
                    str = "<p>" + cursor[count].login + " checked in at " + cursor[count].lat + ", " + cursor[count].lng + " on " + cursor[count].created_at + "</p>";
                    if (cursor[count].created_at < prev_date) {
                        indexPage = indexPage + str;
                    } else {
                        indexPage = str + indexPage;
                    }
                    prev_date = cursor[count].created_at;
				}
                indexPage = "<!DOCTYPE HTML><html><head><title>Checkins</title><link href='stylesheets/index.css' rel='stylesheet' /></head><body><h1>Checkins</h1>" + indexPage;
				indexPage += "</body></html>"
				response.send(indexPage);
			} else {
				response.send('<!DOCTYPE HTML><html><head><title>Checkins</title></head><body><h1>Whoops, something went terribly wrong!</h1></body></html>');
			}
		});
	});
});

app.listen(process.env.PORT || 3000);
