Assignment 3: The Server for Historic Landmarks
1. All features have been implemented correctly.
2. I worked on this assignment alone.
3. I spent approximately 15 hours on this assignment.
